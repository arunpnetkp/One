<?php
$user="root";
$pass="";
$db="earthmove";
$con=new mysqli("localhost",$user,$pass,$db);


?>
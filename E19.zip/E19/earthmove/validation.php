<?php 
include_once('connection.php');
if(isset($_POST['Submit']))
    {
	 //$serno=$_POST['txtSerialNum'];
	 //$currentdate=$_POST[''];
	 $memname=$_POST['txtMemName'];
	 $serno=$_POST['txtSerialnumber'];
	 $memship=$_POST['txtMemShiptype'];
	 $dob=$_POST['date'];
	 $adhar=$_POST['txtAdhar'];
	 $add=$_POST['txtareaAdd'];
	 $lnum=$_POST['txtLphone'];
	 $mob=$_POST['txtMphone'];
	 $dist=$_POST['txtDist'];
	 $pin=$_POST['txtPin'];
	 $nname=$_POST['txtNname'];
	 $nadd=$_POST['txtareaNadd'];
	 $offname=$_POST['txtOfficeName'];
     $offadd=$_POST['txtareaOffadd'];
     $offlnum=$_POST['txtLandoffice'];
     $offmob=$_POST['txtMoboffice'];
     $hnum=$_POST['txtHphone'];
     $lbody=$_POST['txtLocalbody'];
     $area=$_POST['txtArea'];
     $adist=$_POST['txtAdist'];
     $apin=$_POST['txtApin'];
     $vnum=$_POST['txtVnum'];
	 $vtype=$_POST['txtVtype'];	
	 
	 
	 $GLOBALS['serialno']=$serno;
	 $serno=$GLOBALS['serialno'];
	 
	 $error = '';
	 $code = ''; 

	 $vlidationMsg = []; 

	
	 
	if(empty($memname))
	{
	$error = "Enter Member name !";
	$vlidationMsg[] ="Enter Member name !";
	$code = 1;
	}

	 if(!ctype_alpha($memname))
	{
	$vlidationMsg[] = "Member name contain alphabetical letters";
	$code = 1;
	}
	 if(empty($memship))
    {
	$vlidationMsg[] = "enter membership type !";
	$code = 2;
	}
	
	if(empty($adhar))
	{
	$vlidationMsg[] = "Enter Aadhar NO ";
	$code = 3;
	}
	
	if(!is_numeric($adhar))
	{
	$vlidationMsg[] = "Numbers only ";
	$code = 3;
	}
	
	if(strlen($adhar)!=12)
	{
	$vlidationMsg[] = "12 characters only ";
	$code = 3;
	}
	
	if(empty($add))
	{
	$vlidationMsg[] = "Enter Address ";
	$code = 4;
	}
	
	
	if(empty($lnum))
	{
	$vlidationMsg[] = "Enter LandPhone NO ";
	$code = 5;
	}
	if(!is_numeric($lnum))
	{
	$vlidationMsg[] = "Numbers only ";
	$code = 5;
	}
	if(strlen($lnum)!=11)
	{
	$vlidationMsg[] = "11 characters only ";
	$code = 5;
	}
	if(empty($mob))
	{
	$vlidationMsg[] = "Enter Mobile NO !";
	$code = 6;
	}
	if(!is_numeric($mob))
	{
	$vlidationMsg[] = "Numbers only !";
	$code = 6;
	}
	if(strlen($mob)!=10)
	{
	$vlidationMsg[] = "10 numbers only !";
	$code = 6;
	}
	
	
	if(empty($pin))
	{
	$vlidationMsg[] = "Enter Pin NO !";
	$code = 8;
	}
	if(!is_numeric($pin))
	{
	$vlidationMsg[] = "Numbers only !";
	$code = 8;
	}
	if(strlen($pin)!=6)
	{
	$vlidationMsg[] = "6 numbers only !";
	$code = 8;
	}
	if(empty($nname))
	{
	$vlidationMsg[] = "Enter Nominee name !";
	$code = 9;
	}
	if(!ctype_alpha($nname))
	{
	$vlidationMsg[] = "Nominee name contain alphabetical letters";
	$code = 9;
	}
	if(empty($nadd))
	{
	$vlidationMsg[] = "Enter Nominee Address !";
	$code = 10;
	}
	if(empty($offname))
	{
	$vlidationMsg[] = "Enter Office name !";
	$code = 11;
	}
	
	if(empty($offadd))
	{
	$vlidationMsg[] = "Enter Office Address !";
	$code = 12;
	}
	if(empty($offlnum))
	{
	$vlidationMsg[] = "Enter Office LandPhone NO !";
	$code = 13;
	}
	if(!is_numeric($offlnum))
	{
	$vlidationMsg[] = "Numbers only !";
	$code = 13;
	}
	if(strlen($offlnum)!=11)
	{
	$vlidationMsg[] = "11 characters only !";
	$code = 13;
	}
	if(empty($offmob))
	{
	$vlidationMsg[] = "Enter Mobile NO !";
	$code = 14;
	}
	if(!is_numeric($offmob))
	{
	$vlidationMsg[] = "Numbers only !";
	$code = 14;
	}
	if(strlen($offmob)!=10)
	{
	$vlidationMsg[] = "10 numbers only !";
	$code = 14;
	}
	if(empty($hnum))
	{
	$vlidationMsg[] = "Enter House LandPhone NO !";
	$code = 15;
	}
	if(!is_numeric($hnum))
	{
	$vlidationMsg[] = "Numbers only !";
	$code = 15;
	}
	if(strlen($hnum)!=11)
	{
	$vlidationMsg[] = "11 characters only !";
	$code = 15;
	}	
	if(empty($lbody))
	{
	$vlidationMsg[] = "Enter Local body !";
	$code = 16;
	}
	if(!ctype_alpha($lbody))
	{
	$vlidationMsg[] = "Localbody contain alphabetical letters";
	$code = 16;
	}
	if(empty($area))
	{
	$vlidationMsg[] = "Enter Area Name !";
	$code = 17;
	}
	if(!ctype_alpha($area))
	{
	$vlidationMsg[] = "Area contain alphabetical letters";
	$code = 17;
	}
	
	if(empty($apin))
	{
	$vlidationMsg[] = "Enter Pin NO !";
	$code = 19;
	}
	if(!is_numeric($apin))
	{
	$vlidationMsg[] = "Numbers only !";
	$code = 19;
	}
	if(strlen($apin)!=6)
	{
	$vlidationMsg[] = "6 numbers only !";
	$code = 19;
	}
	if(empty($vnum))
	{
	$vlidationMsg[] = "Enter Vehicle NO !";
	$code = 20;
	}
	
	if(empty($vtype))
	{
	$vlidationMsg[] = "Enter Vehicle name !";
	$code = 21;
	}

	if(empty($dob))
	{
	$vlidationMsg[] = "Enter DOB !";
	$code = 212;
	}
	
	$msg="";	   
		
		
	//$_SESSION['vlidation']= $vlidationMsg;


	if(count($vlidationMsg )>0)
	{
		for ($i = 0; $i < count($vlidationMsg ); $i++)
		{
		$msg=$msg.$vlidationMsg[$i]."\\n";        
    	}
		echo "<script>alert('".$msg."')</script>";
	?> 
	
	<script>
		document.location.href='membership.php';		
	</script>
	<?php 
	}
	else
	{
		$result=mysqli_query($con,"INSERT INTO registration ( currentdate,memname, membershiptype, dob, adharno, address, lphone, mobile, district, pin, nname, naddress, offname, offaddress, offlandno, offmob, houseno, localbody, area, adist, apin, vnum, vtype) VALUES
    	(now(),'$memname','$memship','$dob','$adhar','$add','$lnum','$mob','$dist','$pin','$nname','$nadd','$offname','$offadd','$offlnum','$offmob','$hnum','$lbody','$area','$adist','$apin','$vnum','$vtype')"); 
    ?> 
		<script>
    	document.location.href='registration.php?srlNum=<?php echo $serno ?>' ;
		</script>
	<?php
	} 

	
}
?>
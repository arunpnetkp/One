<?php
$user="root";
$pass="";
$db="akp";
$con=new mysqli("localhost",$user,$pass);
?>
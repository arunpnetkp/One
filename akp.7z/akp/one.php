<html>
   <body>
      <?php
         echo "MY First PHP Program";
      ?>
   </body>
</html>
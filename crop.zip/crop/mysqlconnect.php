<?php
$user="root";
$pass="";
$db="sample";
$con=new mysqli("localhost",$user,$pass,$db);


?>
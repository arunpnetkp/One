<?php 
include_once('connection.php');
if(isset($_POST['Submit']))
    {
	 //$serno=$_POST['txtSerialNum'];
	 //$currentdate=$_POST[''];
	 $serno=$_POST['txtSerialnumber'];
	 $memship=$_POST['txtMemShiptype'];
	 echo "$memship";
	 $dob=$_POST['date'];
	 $adhar=$_POST['txtAdhar'];
	 $add=$_POST['txtareaAdd'];
	 $lnum=$_POST['txtLphone'];
	 $mob=$_POST['txtMphone'];
	 $dist=$_POST['txtDist'];
	 $pin=$_POST['txtPin'];
	 $nname=$_POST['txtNname'];
	 $nadd=$_POST['txtareaNadd'];
	 $offname=$_POST['txtOfficeName'];
     $offadd=$_POST['txtareaOffadd'];
     $offlnum=$_POST['txtLandoffice'];
     $offmob=$_POST['txtMoboffice'];
     $hnum=$_POST['txtHphone'];
     $lbody=$_POST['txtLocalbody'];
     $area=$_POST['txtArea'];
     $adist=$_POST['txtAdist'];
     $apin=$_POST['txtApin'];
     $vnum=$_POST['txtVnum'];
     $vtype=$_POST['txtVtype'];	
	 echo $vtype;
	 $GLOBALS['serialno']=$serno;
	 
    $result=mysqli_query($con,"INSERT INTO registration ( currentdate, membershiptype, dob, adharno, address, lphone, mobile, district, pin, nname, naddress, offname, offaddress, offlandno, offmob, houseno, localbody, area, adist, apin, vnum, vtype) VALUES
   (now(),'$memship','$dob','$adhar','$add','$lnum','$mob','$dist','$pin','$nname','$nadd','$offname','$offadd','$offlnum','$offmob','$hnum','$lbody','$area','$adist','$apin','$vnum','$vtype')"); 
     //$result=mysqli_query($con,"insert into registration(serno,currentdate,membershiptype,dob,adharno,address,lphone,mobile,district,pin,nname,naddress,offname,offaddress,offlandno,offmob,houseno,localbody,area,adist,apin,vnum,vtype) 
	 //values ('$serno','$memship','$adhar','$add','$lnum','$mob','$dist','$pin','$nname','$nadd','$offname','$offadd','$offlnum','$offmob','$hnum','$lbody','$area','$adist','$apin','$vnum','$vtype')");
	
	}
?>
<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script> 
<script src="croppie/croppie.js"></script>

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css"> 

<link rel="stylesheet" href="croppie/croppie.css">
<link rel="stylesheet" href="style.css">
<script type="text/javascript" src="upload.js"></script>

</head>

<?php  /* include('container.php'); */ ?>

<body class="">

<div class="modal-lg">
	
	<div class="modal-lg">
	  <div class="modal-lg">
	  	<div class="row">
	  		<div class="col-md-4">
				<div id="upload-image"></div>
	  		</div>
			
	  		<div class="col-md-4">
				<strong>Select Image:</strong>
				<br/>
				<input type="file" id="images">
				<br/>
				<button class="btn btn-success cropped_image">Upload Image</button>
				<input id="txtSerialnumber" name="txtSerialnumber" type="text" value=<?php echo $serialno;?> style="display:none">
	  		</div>	
			
	  		<div class="col-md-4 crop_preview">
				<div id="upload-image-i"></div>				
	  		</div>
	  	</div>
	  </div>
	</div>	
	<br>	
	
</div>
<?php /*include('footer.php');*/?>

</div>
</body></html>

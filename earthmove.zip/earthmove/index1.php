<?php
session_start();
?>
<html>
<head>

</head>
<body>
<?php
if($_SESSION["username"])
	{
?>
Welcome <?php echo $_SESSION["username"]; ?>. Click here to <a href="logout.php" tite="Logout">Logout.
<?php
}else echo "<h1>Please login first .</h1>";
?>
</body>
</html>
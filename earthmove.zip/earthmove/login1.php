<script  src="https://code.jquery.com/jquery-1.11.1.min.js" integrity="sha256-VAvG3sHdS5LqTT+5A/aeq/bZGa/Uj04xKxY8KM/w9EE=" crossorigin="anonymous"></script>

</script><script  src="https://code.jquery.com/jquery-1.11.1.min.js" integrity="sha256-VAvG3sHdS5LqTT+5A/aeq/bZGa/Uj04xKxY8KM/w9EE=" crossorigin="anonymous"></script>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>


<?php
include_once('connection.php');
session_start();
$message="";
if(count($_POST)>0) {
//$con = mysqli_connect('127.0.0.1:3306','root','','admin') or die('Unable To connect');
$result = mysqli_query($con,"SELECT * FROM user WHERE username='" . $_POST["txtUserName"] . "' and password = '". $_POST["txtPassword"]."'");
$row = mysqli_fetch_array($result);
if(is_array($row)) {
$_SESSION["user_id"] = $row['user_id'];
$_SESSION["username"] = $row['username'];
} else {
$message = "Invalid Username or Password!";
}
}
if(isset($_SESSION["user_id"])) {
header("Location:index.php");
}
?>
<html>
<head>
<title>User Login</title>
</head>
<body>
<form class="form-horizontal"  action="" method="post" align="center" form name="frmUser" >

<div class="message"><?php if($message!="") { echo $message; } ?></div>

<!-- Form Name -->
<legend >Enter Login Details</legend><br>
<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="username">Username:</label>  
  <div class="col-md-4">
  <input id="txtUserName" name="txtUserName" type="text"  class="form-control input-md">
  </div>
</div>

<!-- Password input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="password">Password: </label>
  <div class="col-md-4">
    <input id="txtPassword" name="txtPassword" type="password"  class="form-control input-md">
    
  </div>
</div>
<!-- Button -->
<div class="form-group">
	 <span class="col-md-4 control-label" ></span> 
   <div class="col-md-4">
	<input type="submit" button id="submit" name="submit" value="Submit" class="btn btn-default">
  
	<input type="reset" button id="reset" name="reset" value="Reset" class="btn btn-default">

  </div>
</div>


</form>
</body>
</html>
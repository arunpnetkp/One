<?php
include_once('connection.php');
$croped_image = $_POST['image'];
$serno=$_POST['srlno'];
list($type, $croped_image) = explode(';', $croped_image);
list(, $croped_image)      = explode(',', $croped_image);
$croped_image = base64_decode($croped_image);
$image_name = time().'.png';
// upload cropped image to server 
file_put_contents('upload/'.$image_name, $croped_image);
//echo $image_name
echo 'Cropped image uploaded successfully.';
echo $serno;
$result=mysqli_query($con,"UPDATE registration SET imagename ='$image_name' WHERE serialno='$serno'"); 


?>


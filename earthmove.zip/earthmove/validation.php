<?php 
include_once('connection.php');
if(isset($_POST['Submit']))
    {
	 //$serno=$_POST['txtSerialNum'];
	 //$currentdate=$_POST[''];
	 $memname=$_POST['txtMemName'];
	 $serno=$_POST['txtSerialnumber'];
	 $memship=$_POST['txtMemShiptype'];
	 $dob=$_POST['date'];
	 $adhar=$_POST['txtAdhar'];
	 $add=$_POST['txtareaAdd'];
	 $lnum=$_POST['txtLphone'];
	 $mob=$_POST['txtMphone'];
	 $dist=$_POST['txtDist'];
	 $pin=$_POST['txtPin'];
	 $nname=$_POST['txtNname'];
	 $nadd=$_POST['txtareaNadd'];
	 $offname=$_POST['txtOfficeName'];
     $offadd=$_POST['txtareaOffadd'];
     $offlnum=$_POST['txtLandoffice'];
     $offmob=$_POST['txtMoboffice'];
     $hnum=$_POST['txtHphone'];
     $lbody=$_POST['txtLocalbody'];
     $area=$_POST['txtArea'];
     $adist=$_POST['txtAdist'];
     $apin=$_POST['txtApin'];
     $vnum=$_POST['txtVnum'];
     $vtype=$_POST['txtVtype'];	
	 
	 $GLOBALS['serialno']=$serno;
	 
	if(empty($memname))
	{
	$error = "Enter Member name !";
	$code = 1;
	}
	else if(!ctype_alpha($memname))
	{
	$error = "Member name may only contain alphabetical letters";
	$code = 1;
	}
	else if(empty($memship))
    {
	$error = "enter membership type !";
	$code = 2;
	}
	else if(empty($adhar))
	{
	$error = "Enter Aadhar NO !";
	$code = 3;
	}
	else if(!is_numeric($adharno))
	{
	$error = "Numbers only !";
	$code = 3;
	}
	else if(strlen($adharno)!=12)
	{
	$error = "12 characters only !";
	$code = 3;
	}
	else if(empty($add))
	{
	$error = "Enter Address !";
	$code = 4;
	}
	else if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $add))
	{
	$error = "Address contain albhabetic and numbers";
	$code = 4;
	}
	else if(empty($lnum))
	{
	$error = "Enter LandPhone NO !";
	$code = 5;
	}
	else if(!is_numeric($lnum))
	{
	$error = "Numbers only !";
	$code = 5;
	}
	else if(strlen($lnum)!=11)
	{
	$error = "11 characters only !";
	$code = 5;
	}
	else if(empty($mob))
	{
	$error = "Enter Mobile NO !";
	$code = 6;
	}
	else if(!is_numeric($mob))
	{
	$error = "Numbers only !";
	$code = 6;
	}
	else if(strlen($mob)!=10)
	{
	$error = "10 numbers only !";
	$code = 6;
	}
	else if(empty($dist))
	{
	$error = "Enter District name !";
	$code = 7;
	}
	else if(!ctype_alpha($dist))
	{
	$error = "District name may only contain alphabetical letters";
	$code = 7;
	}
	else if(empty($pin))
	{
	$error = "Enter Pin NO !";
	$code = 8;
	}
	else if(!is_numeric($pin))
	{
	$error = "Numbers only !";
	$code = 8;
	}
	else if(strlen($pin)!=6)
	{
	$error = "6 numbers only !";
	$code = 8;
	}
	else if(empty($nname))
	{
	$error = "Enter Member name !";
	$code = 9;
	}
	else if(!ctype_alpha($nname))
	{
	$error = "Nominee name may only contain alphabetical letters";
	$code = 9;
	}
	else if(empty($nadd))
	{
	$error = "Enter Nominee Address !";
	$code = 10;
	}
	else if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $nadd))
	{
	$error = "Nominee Address contain albhabetic and numbers";
	$code = 10;
	}
	
	else if(empty($offname))
	{
	$error = "Enter Office name !";
	$code = 11;
	}
	else if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $offname))
	{
	$error = "Office Name contain albhabetic and numbers";
	$code = 11;
	}
	else if(empty($offadd))
	{
	$error = "Enter Office Address !";
	$code = 12;
	}
	else if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $offadd))
	{
	$error = "Office Address contain albhabetic and numbers";
	$code = 12;
	}
	else if(empty($offlnum))
	{
	$error = "Enter Office LandPhone NO !";
	$code = 13;
	}
	else if(!is_numeric($offlnum))
	{
	$error = "Numbers only !";
	$code = 13;
	}
	else if(strlen($offlnum)!=11)
	{
	$error = "11 characters only !";
	$code = 13;
	}
	else if(empty($offmob))
	{
	$error = "Enter Mobile NO !";
	$code = 14;
	}
	else if(!is_numeric($offmob))
	{
	$error = "Numbers only !";
	$code = 14;
	}
	else if(strlen($offmob)!=10)
	{
	$error = "10 numbers only !";
	$code = 14;
	}
	else if(empty($hnum))
	{
	$error = "Enter House LandPhone NO !";
	$code = 15;
	}
	else if(!is_numeric($hnum))
	{
	$error = "Numbers only !";
	$code = 15;
	}
	else if(strlen($hnum)!=11)
	{
	$error = "11 characters only !";
	$code = 15;
	}	
	else if(empty($lbody))
	{
	$error = "Enter Local body !";
	$code = 16;
	}
	else if(!ctype_alpha($lbody))
	{
	$error = "Localbody contain alphabetical letters";
	$code = 16;
	}
	else if(empty($area))
	{
	$error = "Enter Area Name !";
	$code = 17;
	}
	else if(!ctype_alpha($area))
	{
	$error = "Area contain alphabetical letters";
	$code = 17;
	}
	else if(empty($adist))
	{
	$error = "Enter District name !";
	$code = 18;
	}
	else if(!ctype_alpha($adist))
	{
	$error = "District name may only contain alphabetical letters";
	$code = 18;
	}
	else if(empty($apin))
	{
	$error = "Enter Pin NO !";
	$code = 19;
	}
	else if(!is_numeric($apin))
	{
	$error = "Numbers only !";
	$code = 19;
	}
	else if(strlen($apin)!=6)
	{
	$error = "6 numbers only !";
	$code = 19;
	}
	else if(empty($vnum))
	{
	$error = "Enter Vehicle NO !";
	$code = 20;
	}
	else if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $vnum))
	{
	$error = "Vehicle Number contain alphabetical letters, Numbers and Hyphen ";
	$code = 20;
	}
	else if(empty($vtype))
	{
	$error = "Enter Vehicle name !";
	$code = 21;
	}
	else if(!ctype_alpha($vtype))
	{
	$error = "Vehicle name may only contain alphabetical letters";
	$code = 21;
	}
else
{
?>
 <script>
  document.location.href='membership.php';
 </script>
 <?php
}	
	else
	{
	$result=mysqli_query($con,"INSERT INTO registration ( currentdate,memname, membershiptype, dob, adharno, address, lphone, mobile, district, pin, nname, naddress, offname, offaddress, offlandno, offmob, houseno, localbody, area, adist, apin, vnum, vtype) VALUES
    (now(),'$memname','$memship','$dob','$adhar','$add','$lnum','$mob','$dist','$pin','$nname','$nadd','$offname','$offadd','$offlnum','$offmob','$hnum','$lbody','$area','$adist','$apin','$vnum','$vtype')"); 
    ?>
	<script>
    document.location.href='registeration.php';
	</script>
<?php
	}
}
?>